

#include <stdio.h>
#include <stdlib.h>
#include "systic.h"
#include "show.h"
#include "usart.h"
#include "key.h"
int main(void)
{
	delay_init();
	uart_init(115200);
	key_init();
	while (1)
	{
		key_handle();

	}
}
