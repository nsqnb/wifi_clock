#include "usart.h"
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include "string.h"
uint8_t rev_COUNT=0;
uint8_t usart_flag=0;
uint8_t send_sque=0;
uint8_t rev_DAT[67]={0};
//��ʼ��IO ����1
//bound:������
void uart_init(u32 bound){
    //GPIO�˿�����
    GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1|RCC_APB2Periph_GPIOA, ENABLE);	//ʹ��USART1��GPIOAʱ��
 	USART_DeInit(USART1);  //��λ����1
	 //USART1_TX   PA.9
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; //PA.9
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	//�����������
    GPIO_Init(GPIOA, &GPIO_InitStructure); //��ʼ��PA9
   
    //USART1_RX	  PA.10
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//��������
    GPIO_Init(GPIOA, &GPIO_InitStructure);  //��ʼ��PA10

   //Usart1 NVIC ����

    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3 ;//��ռ���ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���
  
   //USART ��ʼ������

	USART_InitStructure.USART_BaudRate = bound;//һ������Ϊ9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//�ֳ�Ϊ8λ���ݸ�ʽ
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//һ��ֹͣλ
	USART_InitStructure.USART_Parity = USART_Parity_No;//����żУ��λ
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//��Ӳ������������
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//�շ�ģʽ

    USART_Init(USART1, &USART_InitStructure); //��ʼ������
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);//�����ж�
    USART_ClearFlag(USART1, USART_FLAG_TC);
    USART_Cmd(USART1, ENABLE);                    //ʹ�ܴ���

}
void usartX_send(USART_TypeDef* USARTx,uint8_t dat)
{
	USART_ClearFlag(USARTx, USART_FLAG_TC);
	USART_SendData(USARTx, dat);
	while (USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);

}
char *itoa(int value, char *string, int radix)
{
	int     i, d;
	int     flag = 0;
	char    *ptr = string;

	/* This implementation only works for decimal numbers. */
	if (radix != 10)
	{
		*ptr = 0;
		return string;
	}

	if (!value)
	{
		*ptr++ = 0x30;
		*ptr = 0;
		return string;
	}

	/* if this is a negative value insert the minus sign. */
	if (value < 0)
	{
		*ptr++ = '-';

		/* Make the value positive. */
		value *= -1;
	}

	for (i = 10000; i > 0; i /= 10)
	{
		d = value / i;

		if (d || flag)
		{
			*ptr++ = (char)(d + 0x30);
			value -= (d * i);
			flag = 1;
		}
	}

	/* Null terminate the string. */
	*ptr = 0;

	return string;

} /* NCL_Itoa */
void USART_printf(USART_TypeDef * USARTx, char *Data, ...)
{

	const char *s;
	int d,i;
	char buf[16];
	va_list ap;
	va_start(ap, Data);
	while (*Data != 0)     // �ַ����Ƿ����
	{
		if (*Data == 0x5c)  //'\'
		{
			switch (*++Data)
			{
			case 'r':							          //�س���
				usartX_send(USARTx, 0x0d);
				Data++;
				break;
			case 'n':							          //���з�
				usartX_send(USARTx, 0x0a);
				Data++;
				break;
			default:
				Data++;
				break;
			}
		}
		else if (*Data == '%')
		{									                  //
			switch (*++Data)
			{
			case 's':										  //�ַ���
				s = va_arg(ap, const char *);
				d=sizeof(*s);
				for (; d; d--)
				{
					usartX_send(USARTx, *s++);
				}
				Data++;
				break;

			case 'd':										//10����
				d = va_arg(ap, int);
				itoa(d, buf, 10);
				for (s = buf; *s; s++)
				{
					usartX_send(USARTx, *s);
				}
				Data++;
				break;
			case 'x':										//16����
				s=va_arg(ap, const char *);
				d = va_arg(ap, int);
				while(d--)
				{
					sprintf((char *)buf,"%02X",(uint8_t)*s++);
					i=0;
					while(buf[i])
					{
						usartX_send(USARTx, buf[i]);
						i++;
					}
				}
				Data++;
				break;
			default:
				Data++;
				break;
			}
		} /* end of else if */
		else
			usartX_send(USARTx, *Data++);
	}

}

void usart_sendchar(uint8_t dat)
{
	USART_ClearFlag(USART1, USART_FLAG_TC);
	USART_SendData(USART1, dat);
	while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);

}
uint8_t cal_crc(uint8_t *ptr, uint8_t len)
{
	uint8_t i;
	uint8_t crc=0;
	while(len--!=0)
{
		for(i=0x80; i!=0; i/=2)
		{
			if((crc&0x80)!=0)
			{
				crc*=2;
				crc^=0x07;
			}
			else
				crc*=2;
			if((*ptr&i)!=0)
				crc^=0x07;
		}
		ptr++;
}
	return(crc);
}
void USART1_IRQHandler(void)                	//����1�жϷ������
{
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
	{
		rev_DAT[rev_COUNT]=USART_ReceiveData(USART1);
		rev_COUNT++;
		if(rev_DAT[0]!=0xfe||rev_DAT[1]>65)
		{
			rev_COUNT=0;
		}
		if(rev_DAT[1]==(rev_COUNT-2))
		{
			if(rev_DAT[rev_COUNT-1]==0xfc)
			{
				usart_flag=1;
			}
			rev_COUNT=0;
			rev_DAT[0]=0;
		}
	}
}

