/*
 * show.c
 *
 *  Created on: 2019��3��2��
 *      Author: Administrator
 */
#include "stm32f10x_gpio.h"
#include "stm32f10x_spi.h"
#include "show.h"
#include "systic.h"
const uint8_t fseg[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0X00,0XFF};
void SPI2_hal_Init(void)
{
  GPIO_InitTypeDef  GPIO_InitStruct;
  SPI_InitTypeDef   SPI_InitStruct;

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);

  /*!< Configure SD_SPI pins: SCK */
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*!< SD_SPI Config */
  SPI_InitStruct.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStruct.SPI_Mode = SPI_Mode_Master;
  SPI_InitStruct.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStruct.SPI_CPOL = SPI_CPOL_Low;
  SPI_InitStruct.SPI_CPHA = SPI_CPHA_2Edge;
  SPI_InitStruct.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStruct.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_128;
  SPI_InitStruct.SPI_FirstBit = SPI_FirstBit_MSB;
  SPI_InitStruct.SPI_CRCPolynomial = 7;
  SPI_Init(SPI2, &SPI_InitStruct);
  SPI_Cmd(SPI2, ENABLE); /*!< SD_SPI enable */

}
//spi
uint8_t SPI_hal_SendReadByte(uint8_t byte)
{
  uint8_t retry=0;
  /* Loop while DR register in not emplty */
  while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET)
  {
	  retry++;
	  if(retry>200)
		  return 0;
  }

  /* Send byte through the SPI1 peripheral */
  SPI_I2S_SendData(SPI2, byte);

  /* Wait to receive a byte */
  while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET)
  {
	  retry++;
	  if(retry>200)
		  return 0;
  }
  /* Return the byte read from the SPI bus */
  return SPI_I2S_ReceiveData(SPI2);
}
void shuma_led_show(uint8_t dataH,uint8_t dotH,uint8_t dataL,uint8_t dotL)
{
	if(dotH)
	{
		SPI_hal_SendReadByte(fseg[dataH]& 0X7F);
	}
	else{
		SPI_hal_SendReadByte(fseg[dataH]);
	}
	if(dotL)
	{
		SPI_hal_SendReadByte(fseg[dataL]& 0X7F);
	}
	else{
		SPI_hal_SendReadByte(fseg[dataL]);
	}


	H595_RCK_L;
	delay_ms(10);
    H595_RCK_H;
}
void shuma_led_init(void)
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB, ENABLE);
	SPI2_hal_Init();

	GPIO_InitStruct.GPIO_Pin =GPIO_Pin_12;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStruct);

	GPIO_InitStruct.GPIO_Pin =GPIO_Pin_8;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);

	H595_OE_L;
	H595_RCK_H;

	shuma_led_show(10,1,10,1);
	delay_ms(500);
	delay_ms(500);
	shuma_led_show(0,0,0,0);

}



