/*
 * key.h
 *
 *  Created on: 2019��3��2��
 *      Author: Administrator
 */

#ifndef KEY_H_
#define KEY_H_
#include "stm32f10x_gpio.h"
extern uint8_t chanel_num;
#define KEY_UP   GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11)
#define KEY_DOWN  GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_12)

#define BOMA1  GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6)
#define BOMA2   GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5)
#define BOMA3  GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4)
#define BOMA4   GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3)
#define BOMA5  GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_15)

typedef struct{
	uint8_t KEY_UP_flag :1;
	uint8_t KEY_DOWN_flag :1;
	uint8_t BOMA1_flag :1;
	uint8_t BOMA2_flag :1;
	uint8_t BOMA3_flag :1;
	uint8_t BOMA4_flag :1;
	uint8_t BOMA5_flag :1;
	uint8_t BOMA6_flag :1;
}flag;

void key_init(void);
void key_handle(void);
#endif /* KEY_H_ */
