/*
 * key.c
 *
 *  Created on: 2019��3��2��
 *      Author: Administrator
 */
#include "key.h"
#include "systic.h"
#include "usart.h"
flag key_flag={0};
uint8_t chanel_num=0;
void key_init(void)
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);

	GPIO_InitStruct.GPIO_Pin =GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_15;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);

	GPIO_InitStruct.GPIO_Pin =GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStruct);

	GPIO_SetBits(GPIOA,GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_15);
	GPIO_SetBits(GPIOB,GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6);
}
void key_handle(void)
{
	if(KEY_UP==0)
	{
		delay_ms(20);
		if(KEY_UP==0)
		{
			if(!key_flag.KEY_UP_flag){
				key_flag.KEY_UP_flag=1;
				if(BOMA1==0)
				{
						chanel_num=40;
				}
				else
				{
					if(chanel_num<80)
						chanel_num++;
				}
			}
		}
	}
	else{
		key_flag.KEY_UP_flag=0;
	}

	if(KEY_DOWN==0)
	{
		delay_ms(20);
		if(KEY_DOWN==0)
		{
			if(!key_flag.KEY_DOWN_flag){
				key_flag.KEY_DOWN_flag=1;
				if(BOMA1==0)
				{
						chanel_num=0;
				}
				else
				{
					if(chanel_num>0)
						chanel_num--;
				}
			}
		}
	}
	else{
		key_flag.KEY_DOWN_flag=0;
	}
}
