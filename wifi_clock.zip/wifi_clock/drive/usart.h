#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "stm32f10x_conf.h"
void uart_init(u32 bound);
void USART_printf(USART_TypeDef * USARTx, char *Data, ...);
void usart_sendchar(uint8_t dat);
void usartX_send(USART_TypeDef* USARTx,uint8_t dat);
#endif


