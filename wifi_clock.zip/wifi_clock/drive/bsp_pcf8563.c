#include "bsp_pcf8563.h"
#include "oled.h"

unsigned char setTime[6]={0x00,0x00,0x00,0x00,0x00,0x00};
unsigned char realTime[7];
unsigned char readtime[3];

//Pcf8563_TIME Pcf8563_Time;
typedef struct 
{	
	char sec;
	char min;
	char hour;
	char day;
	char month;
	int year;
}TIME;

TIME time;

void Pcf8563_Gpio_Init(void)
{
	GPIO_InitTypeDef	GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
}

void I2c_Delay(void)
{
	uint8_t i;
	for(i=10;i>0;i--);
}

void I2c_Start(void)
{
	I2c_Scl_1();
	I2c_Sda_1();
	I2c_Delay();
	I2c_Sda_0();
	I2c_Delay();
	I2c_Scl_0();
}

void I2c_Stop(void)
{
	I2c_Scl_0();
	I2c_Sda_0();
	I2c_Delay();
	I2c_Scl_1();
	I2c_Delay();
	I2c_Sda_1();	
}

u8 I2c_WriteByte(unsigned char byte)
{
	u8 mask = 0x80;
	u8 ack;
	
	for(;mask>0;mask>>=1)
	{
		if(byte&mask)
		{
			I2c_Sda_1();
		}
		else
		{
			I2c_Sda_0();
		}
		I2c_Delay();
		I2c_Scl_1();
		I2c_Delay();
		I2c_Scl_0();
	}
	I2c_Sda_1();		//�ͷ����ߣ�׼�����մӻ��Ļش�
	I2c_Delay();
	I2c_Scl_1();
	ack = I2c_Sda_Read();
	I2c_Delay();
	I2c_Scl_0();
	
	return ack;
}

u8 I2c_ReadByte(void)
{
	u8 mask,data;
	
	I2c_Sda_1();	//�ͷ���������
	for(mask=0x80;mask>0;mask>>=1)
	{
		I2c_Scl_1();
		I2c_Delay();
		
		if(I2c_Sda_Read()==1)
		{
			data |= mask;
		}
		else
		{
			data &= ~mask;
		}
		I2c_Scl_0();
		I2c_Delay();
	}
	
	return data;
}

//��ȡ�ӻ�һ���ֽ�����֮���������ȡ��һ������ʱ������NAK���ӻ�
void I2c_Nak(void)
{
	I2c_Sda_1();		//NAK
	I2c_Delay();
	I2c_Scl_1();
	I2c_Delay();
	I2c_Scl_0();
}
//��ȡ�ӻ�һ���ֽ�����֮���������ȡ��һ������ʱ������ACK���ӻ�
void I2c_Ack(void)
{
	I2c_Sda_0();		//ACK
	I2c_Delay();
	I2c_Scl_1();
	I2c_Delay();
	I2c_Scl_0();
}

void Pcf8563_WriteByte(unsigned char addr,unsigned char dat)
{
	I2c_Start();
	I2c_WriteByte(I2C_WriteAddress);
	I2c_WriteByte(addr);
	I2c_WriteByte(dat);
	I2c_Stop();
}

u8 Pcf8563_ReadByte(unsigned char addr)
{
	unsigned char data;
	
	I2c_Start();
	I2c_WriteByte(I2C_WriteAddress); 
	I2c_WriteByte(addr);
	I2c_Start();
	I2c_WriteByte(I2C_ReadAddress);
	
	data = I2c_ReadByte();
	I2c_Nak();
	I2c_Stop();
	
	return data;
}

void Pcf8563_ReadBytes(unsigned char addr,unsigned char count,unsigned char *buf)
{
	unsigned char i;
	
	I2c_Start();
	I2c_WriteByte(I2C_WriteAddress);
	I2c_WriteByte(addr);
	I2c_Start();
	I2c_WriteByte(I2C_ReadAddress);
	
	for(i=0;i<count;i++)
	{
		*(buf+i) = I2c_ReadByte();
		if(i<(count-1))
		{
			I2c_Ack();
		}
	}
	I2c_Nak();
	I2c_Stop();
}

void Pcf8563_Config(void)
{
	Pcf8563_WriteByte(0x00,0x00);
	Pcf8563_WriteByte(0x01,0x11);
}

//����ʱ�ӵ�һ�γ�ʼ��ʱ��оƬ������ʱ��(֮������ε��ͺ�)
void Pcf8563_SetTime(void)
{	
	Pcf8563_WriteByte(0x08,setTime[0]);
	Pcf8563_WriteByte(0x07,setTime[1]);
	Pcf8563_WriteByte(0x05,setTime[2]);
	Pcf8563_WriteByte(0x04,setTime[3]);
	Pcf8563_WriteByte(0x03,setTime[4]);
	Pcf8563_WriteByte(0x02,setTime[5]);
}


void Pcf8563_GetTime(void)
{
	Pcf8563_ReadBytes(0x02,7,realTime);
	
	time.sec = realTime[0] & 0x7f;
	time.min = realTime[1] & 0x7f;
	time.hour = realTime[2] & 0x3f;
	time.day  = realTime[3] & 0x3f;
	time.month = realTime[5] & 0x1f;
	time.year = realTime[6] & 0xff;

	time.sec = 10*(time.sec/16)+time.sec%16;
	time.min = 10*(time.min/16)+time.min%16;
	time.hour = 10*(time.hour/16)+time.hour%16;
	time.day = 10*(time.day/16)+time.day%16;
	time.month = 10*(time.month/16)+time.month%16;
	time.year = 2000+10*(time.year/16)+time.year%16;

//	printf("%d %d %d %d %d %d\r\n",time.year,time.month,time.day,time.hour,time.min,time.sec);
	
	readtime[0]=time.hour;
	readtime[1]=time.min;
	readtime[2]=time.sec;	
}

void Pcf8563_ShowTime(void)
{
	//��
		OLED_ShowNum(5,0,time.year,4,16);
	//��
		OLED_ShowNum(62,0,time.month,2,16);
	//��
		OLED_ShowNum(99,0,time.day,2,16);
	//ʱ
		OLED_ShowNum(30,6,time.hour,2,16);
	//��
		OLED_ShowNum(59,6,time.min,2,16);
	//��
		OLED_ShowNum(86,6,time.sec,2,16);
}



