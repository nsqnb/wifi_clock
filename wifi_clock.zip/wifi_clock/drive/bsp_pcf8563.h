#ifndef		__BSP_PCF8563_H
#define		__BSP_PCF8563_H

#include "stm32f10x.h"

#define		I2C_WriteAddress		0xA2
#define		I2C_ReadAddress			0xA3

#define		I2c_Sda_1()			GPIO_SetBits(GPIOB,GPIO_Pin_7)
#define		I2c_Sda_0()			GPIO_ResetBits(GPIOB,GPIO_Pin_7)
#define		I2c_Scl_1()			GPIO_SetBits(GPIOB,GPIO_Pin_6)
#define		I2c_Scl_0()			GPIO_ResetBits(GPIOB,GPIO_Pin_6)
#define		I2c_Sda_Read()		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7)

extern unsigned char readtime[3];
extern unsigned char setTime[6];


void Pcf8563_ShowTime(void);
void Pcf8563_Gpio_Init(void);
void Pcf8563_Config(void);
void I2c_Start(void);
void I2c_Delay(void);
u8 I2c_WriteByte(unsigned char byte);
u8 I2c_ReadByte(void);
void I2c_Ack(void);
void I2c_Nak(void);
void I2c_Stop(void);
void Pcf8563_WriteByte(unsigned char addr,unsigned char dat);
u8 Pcf8563_ReadByte(unsigned char addr);
void Pcf8563_ReadBytes(unsigned char addr,unsigned char count,unsigned char *buf);
void Pcf8563_SetTime(void);
void Pcf8563_GetTime(void);

#endif
