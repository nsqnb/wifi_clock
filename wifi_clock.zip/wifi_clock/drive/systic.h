/*
 * systic.h
 *
 *  Created on: 2018��2��9��
 *      Author: Administrator
 */

#ifndef INC_SYSTIC_H_
#define INC_SYSTIC_H_
#include "stm32f10x_conf.h"
void delay_init(void);
void delay_ms(u16 nms);
void delay_us(u32 nus);



#endif /* INC_SYSTIC_H_ */
