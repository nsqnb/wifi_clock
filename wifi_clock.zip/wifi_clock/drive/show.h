/*
 * show.h
 *
 *  Created on: 2019��3��2��
 *      Author: Administrator
 */

#ifndef SHOW_H_
#define SHOW_H_
#define H595_OE_H    GPIO_SetBits(GPIOB,GPIO_Pin_12)
#define H595_OE_L    GPIO_ResetBits(GPIOB,GPIO_Pin_12)
#define H595_RCK_H   GPIO_SetBits(GPIOA,GPIO_Pin_8)
#define H595_RCK_L   GPIO_ResetBits(GPIOA,GPIO_Pin_8)

void shuma_led_init(void);
void shuma_led_show(uint8_t dataH,uint8_t dotH,uint8_t dataL,uint8_t dotL);
#endif /* SHOW_H_ */
